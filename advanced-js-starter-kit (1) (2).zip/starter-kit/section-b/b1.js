/*
 * B1 — The array comes back empty
 *
 * (a) The bug in one line:
 *
 * (b) Root cause (2-3 lines):
 *
 * Sequential or concurrent, and why:
 */

// ---- original (buggy) ------------------------------------------------
// async function loadUsers(ids) {
//   const users = [];
//
//   ids.forEach(async (id) => {
//     const res = await fetch(`https://dummyjson.com/users/${id}`);
//     users.push(await res.json());
//   });
//
//   return users;
// }

// ---- your fix ----------------------------------------------------------

async function loadUsers(ids) {
  // TODO
}

loadUsers([1, 2, 3]).then((users) => console.log(users.length));
