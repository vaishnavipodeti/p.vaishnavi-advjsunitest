// A1 — Predict the output (5 marks)
// Write your prediction BEFORE running this file.

console.log('A');

setTimeout(() => console.log('B'), 0);

Promise.resolve().then(() => console.log('C'));

console.log('D');

// Output:
// .............

// Reasoning:
// .............
