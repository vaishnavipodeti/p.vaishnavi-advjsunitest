// A3 — Predict the output (5 marks)
// Write your prediction BEFORE running this file.

async function first() {
  console.log('1');
  await second();
  console.log('2');
}

async function second() {
  console.log('3');
}

console.log('4');
first();
console.log('5');

// Output:
// .............

// Reasoning:
// .............
